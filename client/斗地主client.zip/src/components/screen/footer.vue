<template>
  <div class="footer">
    footer
  </div>
</template>

<script>
  export default {

  };
</script>

<style lang="less" scoped>
  .footer {
    width: 100%;
    height: 45px;
    background: rgba(255, 255, 255, 0.5);
  }
</style>
